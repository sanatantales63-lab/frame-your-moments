import React, { useRef, useState } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { 
  Check, 
  Star, 
  ArrowRight, 
  Film, 
  Heart, 
  Shield, 
  ChevronLeft, 
  ChevronRight,
  Camera,
  Video,
  BookOpen,
  Sparkles,
  Gift,
  Award,
  Layers,
  Table as TableIcon,
  Grid as GridIcon,
  X,
  MessageCircle,
  Clock,
  Shirt,
  Sparkle
} from 'lucide-react';
import confetti from 'canvas-confetti';

/* ════════════════════════════════════════════════════════════════════
   PACKAGE DATA (Extracted from official PDF specifications)
   ════════════════════════════════════════════════════════════════════ */

const CATEGORIES = [
  { id: 'both_side', label: 'Both Side Wedding', badge: '3-4 Days' },
  { id: 'single_side', label: 'Single Side Wedding', badge: '2-3 Days' },
  { id: 'pre_wedding', label: 'Pre-Wedding', badge: '1-2 Days' },
  { id: 'engagement', label: 'Engagement', badge: '1 Day' },
];

const PACKAGES_DATA = {
  both_side: [
    {
      id: 'bs-basic',
      name: 'Basic Wedding',
      subCat: 'both',
      tagline: 'Ideal for Both Side Celebrations',
      originalPrice: '75,000',
      price: '65,000',
      discountNote: 'Save ₹10,000',
      accent: '#C5A059',
      popular: false,
      badge: 'Save ₹10,000',
      duration: '3 Days Both Side',
      photographers: '2 Photographers',
      cinematographers: '2 Cinematographers',
      drone: 'Not Included',
      photos: 'All Raw Soft Copies + 250 (125+125) Edited Pictures',
      album: '2 Plezer Album 40 Pages (20 Sheets)',
      video: '1 Reel, 1 Mint Teaser, 35 Mints Full Video',
      extraDeliverables: [],
      rating: '4.9 Google Reviews & 35+ Wedding Cover Previous Year',
      keyHighlights: [
        '3 Days Both Side Coverage',
        '2 Photographers + 2 Cinematographers',
        '2 Plezer Luxury Albums (40 Pgs)',
        '250 Edited Pictures + All Raw Copies',
        '35 Mints Cinematic Full Video + Teaser'
      ]
    },
    {
      id: 'bs-standard',
      name: 'Standard Wedding',
      subCat: 'both',
      tagline: 'Complete Family & Rituals Coverage',
      originalPrice: '85,000',
      price: '75,000',
      discountNote: 'Save ₹10,000',
      accent: '#D4AF37',
      popular: false,
      badge: 'Save ₹10,000',
      duration: '3 Days Both Side',
      photographers: '2 Photographers',
      cinematographers: '2 Cinematographers',
      drone: 'Not Included',
      photos: 'All Raw Soft Copies + 400 (200+200) Edited Pictures',
      album: '2 Plezer Album 60 Pages (30 Sheets) + 2 Plezer Minibooks',
      video: '1 Reel / Highlights, 2-3 Mints Trailer, 35-45 Mints Full Video',
      extraDeliverables: ['2 Digital Albums', '2 Calendars', '1 Pen Drive 32 GB'],
      rating: '4.9 Google Reviews & 35+ Wedding Cover Previous Year',
      keyHighlights: [
        '3 Days Both Side Coverage',
        '2 Plezer Albums (60 Pgs) + 2 Minibooks',
        '400 Edited Pictures + All Raw Copies',
        '2 Digital Albums + 2 Calendars + 32GB Pen Drive',
        'Reel + 2-3 Min Trailer + 35-45 Min Video'
      ]
    },
    {
      id: 'bs-premium',
      name: 'Premium Wedding',
      subCat: 'both',
      tagline: 'Our Most Loved Canvera Experience',
      originalPrice: '95,000',
      price: '85,000',
      discountNote: 'Save ₹10,000',
      accent: '#E64A6E',
      popular: true,
      badge: 'Most Popular',
      duration: '3 Days Both Side',
      photographers: '2 Photographers',
      cinematographers: '2 Cinematographers',
      drone: 'Not Included',
      photos: 'All Raw Soft Copies + 400 (200+200) Edited Pictures',
      album: '2 Canvera Album 60 Pages (30 Sheets) + 2 Canvera Minibooks',
      video: '2 Reels / Highlights, 2-3 Mints Trailer, 35-60 Mints Full Video',
      extraDeliverables: ['2 Digital Albums', '2 Calendars', '1 Pen Drive 64 GB'],
      rating: '4.9 Google Reviews & 35+ Wedding Cover Previous Year',
      keyHighlights: [
        'Luxury Canvera Albums (60 Pgs) + 2 Minibooks',
        '2 Instagram Reels / Highlights',
        '400 Edited Pictures + All Raw Copies',
        '2 Digital Albums + 2 Calendars + 64GB Pen Drive',
        '2-3 Min Trailer + 35-60 Min Full Video'
      ]
    },
    {
      id: 'bs-premium-plus',
      name: 'Premium Plus Wedding',
      subCat: 'both',
      tagline: 'Extended Coverage with Aerial Drone',
      originalPrice: '1,10,000',
      price: '1,00,000',
      discountNote: 'Save ₹10,000',
      accent: '#9B51E0',
      popular: false,
      badge: 'Includes Drone',
      duration: '3+1 Days Both Side',
      photographers: '2 + 1 Photographers',
      cinematographers: '2 + 1 Cinematographers',
      drone: '1 Drone for Wedding Day',
      photos: 'All Raw Soft Copies + 400 (200+200) Edited Pictures',
      album: '2 Premium Canvera Album 60 Pages (30 Sheets) + 2 Canvera Minibooks',
      video: '3 Reels / Highlights, 2-3 Mints Trailer, 35-60 Mints Full Video',
      extraDeliverables: ['2 Digital Albums', '2 Calendars', '1 Pen Drive 64 GB'],
      rating: '4.9 Google Reviews & 35+ Wedding Cover Previous Year',
      keyHighlights: [
        '3+1 Days Both Side Full Coverage',
        '1 4K Aerial Drone for Wedding Day',
        '3 Photographers + 3 Cinematographers',
        '2 Premium Canvera Albums (60 Pgs)',
        '3 Reels + Trailer + 64GB Pen Drive'
      ]
    },
    {
      id: 'bs-elite',
      name: 'Elite Wedding',
      subCat: 'both',
      tagline: 'Grand Royal Cinematic Celebration',
      originalPrice: '1,30,000',
      price: '1,20,000',
      discountNote: 'Save ₹10,000',
      accent: '#C5A059',
      popular: false,
      badge: 'Royal Grandeur',
      duration: '3+1 Days Both Side',
      photographers: '2 + 1 Photographers',
      cinematographers: '2 + 1 Cinematographers',
      drone: '1 Drone for Wedding + Reception Day',
      photos: 'All Raw Soft Copies + 500 (250+250) Edited Pictures',
      album: '2 Premium Canvera Album 80 Pages (40 Sheets) + 2 Canvera Minibooks',
      video: '3 Reels / Highlights, 2-3 Mints Trailer, 35-60 Mints Full Video',
      extraDeliverables: ['2 Digital Albums', '2 Calendars', '1 Pen Drive 64 GB'],
      rating: '4.9 Google Reviews & 35+ Wedding Cover Previous Year',
      keyHighlights: [
        'Dual-Day Aerial Drone (Wedding + Reception)',
        '80 Pages (40 Sheets) Master Canvera Albums',
        '500 Edited Pictures + All Raw Copies',
        '3 Photographers + 3 Cinematographers',
        'Complete Premium Deliverable Bundle'
      ]
    }
  ],

  single_side: [
    {
      id: 'ss-3day-basic',
      name: 'Basic 3-Day Wedding',
      subCat: '3days',
      tagline: '3 Days Single Side (Groom or Bride)',
      originalPrice: '65,000',
      price: '55,000',
      discountNote: 'Save ₹10,000',
      accent: '#C5A059',
      popular: false,
      badge: '3-Day Package',
      duration: '3 Days Groom / Bride Side',
      photographers: '1 Photographer',
      cinematographers: '1 Cinematographer',
      drone: 'Not Included',
      photos: 'All Raw Soft Copies + 125 Edited Pictures',
      album: '1 Plezer Album 40 Pages (20 Sheets) + 1 Plezer Minibook',
      video: '1 Reel / Highlights, 2-3 Mints Trailer, 35-45 Mints Full Video',
      extraDeliverables: ['1 Digital Album', '1 Calendar', '1 Pen Drive 32 GB'],
      rating: '4.9 Google Reviews',
      keyHighlights: [
        '3 Days Single Side Coverage',
        '1 Plezer Album (40 Pgs) + 1 Minibook',
        '125 Edited Pictures + All Raw Copies',
        'Digital Album + Calendar + 32GB Pen Drive',
        '1 Reel + Trailer + 35-45 Min Video'
      ]
    },
    {
      id: 'ss-2day-basic',
      name: 'Basic 2-Day Package',
      subCat: '2days',
      price: '40,000',
      tagline: 'Essential 2 Days Coverage',
      accent: '#4B5563',
      popular: false,
      duration: '2 Days',
      photographers: '1 Crop Photographer',
      cinematographers: '1 Crop Cinematographer',
      drone: 'Not Included',
      photos: 'All Raw Soft Copies + 125 Edited Pictures',
      album: '1 Plezer Album 40 Pages',
      video: '1 Mint Teaser, 35 Mints Full Video',
      extraDeliverables: [],
      keyHighlights: [
        '2 Days Coverage',
        '1 Crop Photographer + 1 Crop Cinematographer',
        '1 Plezer Album 40 Pages',
        '125 Edited Pictures + All Raw Copies',
        '1 Min Teaser + 35 Min Full Video'
      ]
    },
    {
      id: 'ss-2day-standard',
      name: 'Standard 2-Day Package',
      subCat: '2days',
      price: '45,000',
      tagline: 'Complete 2-Day Single Side Coverage',
      accent: '#D4AF37',
      popular: false,
      duration: '2 Days',
      photographers: '2 Crop Photographers',
      cinematographers: '2 Crop Cinematographers',
      drone: 'Not Included',
      photos: 'All Raw Soft Copies + 200 Edited Pictures',
      album: '1 Plezer Album 60 Pages + Minibook',
      video: '1 Reel / Highlights, 2-3 Mints Trailer, 35-45 Mints Full Video',
      extraDeliverables: ['Digital Album', 'Calendar', '32 GB Pen Drive'],
      keyHighlights: [
        '2 Crop Photographers + 2 Crop Cinematographers',
        '1 Plezer Album 60 Pages + Minibook',
        '200 Edited Pictures + All Raw Copies',
        'Digital Album + Calendar + 32GB Pen Drive',
        '1 Reel + 2-3 Min Trailer + Full Video'
      ]
    },
    {
      id: 'ss-2day-premium',
      name: 'Premium 2-Day Package',
      subCat: '2days',
      price: '55,000',
      tagline: 'Full Frame High-Definition Craft',
      accent: '#E64A6E',
      popular: true,
      badge: 'Most Popular',
      duration: '2 Days',
      photographers: '1 Full Frame + 1 Crop Photographer',
      cinematographers: '1 Full Frame + 1 Crop Cinematographer',
      drone: 'Not Included',
      photos: 'All Raw Soft Copies + 200 Edited Pictures',
      album: '1 Canvera Album 60 Pages + Minibook',
      video: '2 Reels / Highlights, 2-3 Mints Trailer, 35-60 Mints Full Video',
      extraDeliverables: ['Digital Album', 'Calendar', '64 GB Pen Drive'],
      keyHighlights: [
        'Full Frame Sensor Master Cameras',
        '1 Canvera Luxury Album 60 Pages + Minibook',
        '2 Reels + 2-3 Min Trailer + Full Video',
        '200 Edited Pictures + All Raw Copies',
        'Digital Album + Calendar + 64GB Pen Drive'
      ]
    },
    {
      id: 'ss-2day-premium-plus',
      name: 'Premium Plus 2-Day',
      subCat: '2days',
      price: '65,000',
      tagline: 'Dual Full Frame + Aerial Drone',
      accent: '#9B51E0',
      popular: false,
      badge: 'Includes Drone',
      duration: '2 Days',
      photographers: '2 Full Frame Photographers',
      cinematographers: '2 Full Frame Cinematographers',
      drone: '1 Drone for Wedding Day',
      photos: 'All Raw Soft Copies + 200 Edited Pictures',
      album: '1 Premium Canvera Album 60 Pages + Minibook',
      video: '3 Reels / Highlights, 2-3 Mints Trailer, 35-60 Mints Full Video',
      extraDeliverables: ['Digital Album', 'Calendar', '64 GB Pen Drive'],
      keyHighlights: [
        '2 Full Frame Photographers + 2 Cinematographers',
        '1 4K Drone Aerial Coverage',
        '1 Premium Canvera Album 60 Pages',
        '3 Reels + Trailer + 35-60 Min Video',
        'Digital Album + Calendar + 64GB Pen Drive'
      ]
    }
  ],

  pre_wedding: [
    {
      id: 'pw-basic',
      name: 'Basic Pre-Wedding',
      subCat: 'pre',
      price: '15,000',
      tagline: '1 Day Outdoor Romance Shoot',
      accent: '#C5A059',
      popular: false,
      duration: '1 Day',
      photographers: '1 Photographer',
      cinematographers: '1 Cinematographer',
      drone: 'Not Included',
      photos: 'All Raw Soft Copies + 15 Edited Pictures',
      album: 'Not Included',
      video: '3-4 Mints Cinematic Video',
      makeupDress: 'Not Included',
      keyHighlights: [
        '1 Day Outdoor Session',
        '1 Photographer + 1 Cinematographer',
        '15 High-Retouched Pictures',
        'All Raw Soft Copies',
        '3-4 Mints Cinematic Video'
      ]
    },
    {
      id: 'pw-standard',
      name: 'Standard Pre-Wedding',
      subCat: 'pre',
      price: '20,000',
      tagline: 'Includes Printed Photo Book',
      accent: '#D4AF37',
      popular: false,
      duration: '1 Day',
      photographers: '1 Photographer',
      cinematographers: '1 Cinematographer',
      drone: 'Not Included',
      photos: 'All Raw Soft Copies + 15-20 Edited Pictures',
      album: 'Custom Photo Book',
      video: '3-4 Mints Cinematic Video',
      makeupDress: 'Not Included',
      keyHighlights: [
        '1 Day Outdoor Location Shoot',
        'Custom Printed Photo Book Album',
        '15-20 Edited Pictures',
        'All Raw Soft Copies Included',
        '3-4 Mints Cinematic Story Film'
      ]
    },
    {
      id: 'pw-premium',
      name: 'Premium Pre-Wedding',
      subCat: 'pre',
      price: '25,000',
      tagline: 'Includes Professional Makeup & Drone',
      accent: '#00A896',
      popular: false,
      badge: 'Includes Makeup',
      duration: '1 Day',
      photographers: '1 Photographer',
      cinematographers: '1 Cinematographer',
      drone: '1 Drone Included',
      photos: 'All Raw Soft Copies + 20-25 Edited Pictures',
      album: 'Custom Photo Book',
      video: '30 Sec Teaser, 3-4 Mints Cinematic Video',
      makeupDress: 'Professional Bridal Makeup Included',
      keyHighlights: [
        'Professional Makeup Artist Included',
        '1 4K Aerial Drone Coverage',
        'Custom Photo Book Album',
        '30 Sec Teaser + 3-4 Min Cinematic Video',
        '20-25 Retouched Pictures + All Raws'
      ]
    },
    {
      id: 'pw-premium-plus',
      name: 'Premium Plus Pre-Wedding',
      subCat: 'pre',
      price: '35,000',
      tagline: 'Complete Makeup & Designer Outfit Bundle',
      accent: '#E64A6E',
      popular: true,
      badge: 'Most Popular',
      duration: '1 Day',
      photographers: '1 Photographer',
      cinematographers: '1 Cinematographer',
      drone: '1 Drone Included',
      photos: 'All Raw Soft Copies + 25-30 Edited Pictures',
      album: 'Custom Photo Book',
      video: '30 Sec Teaser, 3-4 Mints Cinematic Video',
      makeupDress: 'Professional Makeup + Designer Dress Included',
      keyHighlights: [
        'Professional Makeup + Designer Outfits Included',
        '1 Aerial Drone Location Shoot',
        'Custom Photo Book Album',
        '30 Sec Teaser + 3-4 Min Cinematic Video',
        '25-30 High-Retouched Pictures + All Raws'
      ]
    },
    {
      id: 'pw-elite',
      name: 'Elite Pre-Wedding',
      subCat: 'pre',
      price: '40,000',
      tagline: '2-Day Cinematic Fashion & Location Film',
      accent: '#C5A059',
      popular: false,
      badge: '2-Day Cinema Shoot',
      duration: '2 Days Shoot',
      photographers: '1 Photographer',
      cinematographers: '1 Cinematographer',
      drone: '1 Drone Included',
      photos: 'All Raw Soft Copies + 40-50 Edited Pictures',
      album: 'Custom Photo Book',
      video: '30 Sec Teaser, 3-4 Mints Cinematic Video',
      makeupDress: 'Professional Makeup + Designer Dress Included',
      keyHighlights: [
        '2 Days Multi-Location Shoot',
        'Makeup Artist & Designer Wardrobe',
        '1 Aerial Drone Cinematography',
        '40-50 Master Retouched Pictures',
        'Full Premium Pre-Wedding Album'
      ]
    }
  ],

  engagement: [
    {
      id: 'eng-basic',
      name: 'Basic Engagement Package',
      subCat: 'eng',
      tagline: 'Complete Engagement Day Celebration',
      originalPrice: '30,000',
      price: '25,000',
      discountNote: 'Save ₹5,000',
      accent: '#E64A6E',
      popular: true,
      badge: 'Save ₹5,000',
      duration: '1 Day Event',
      photographers: '1 Photographer',
      cinematographers: '1 Cinematographer',
      drone: 'Not Included',
      photos: 'All Raw Soft Copies + 125 Edited Pictures',
      album: '1 Plezer Album 40 Pages (20 Sheets) + 1 Plezer Minibook',
      video: '1 Reel / Highlights, 2-3 Mints Trailer, 35-45 Mints Full Video',
      extraDeliverables: ['1 Digital Album', '1 Calendar', '1 Pen Drive 32 GB'],
      rating: '4.9 Google Reviews & 35+ Wedding Cover Previous Year',
      keyHighlights: [
        '1 Day Full Engagement Event Coverage',
        '1 Photographer + 1 Cinematographer',
        '1 Plezer Album (40 Pgs) + 1 Minibook',
        '1 Reel + 2-3 Min Trailer + 35-45 Min Video',
        'Digital Album + Calendar + 32GB Pen Drive'
      ]
    }
  ]
};

/* ── Custom Styling & Micro-animations ── */
const pricingStyles = `
@keyframes goldShine {
  0% { transform: translateX(-100%) rotate(25deg); }
  100% { transform: translateX(200%) rotate(25deg); }
}
.gold-shimmer-bar {
  position: relative;
  overflow: hidden;
}
.gold-shimmer-bar::after {
  content: '';
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: linear-gradient(
    60deg,
    transparent 30%,
    rgba(255, 255, 255, 0.4) 50%,
    transparent 70%
  );
  animation: goldShine 4s ease-in-out infinite;
}
.custom-table-scrollbar {
  scrollbar-width: thin;
  scrollbar-color: #C5A059 #FAF7F2;
}
.custom-table-scrollbar::-webkit-scrollbar {
  height: 6px;
}
.custom-table-scrollbar::-webkit-scrollbar-thumb {
  background-color: #C5A059;
  border-radius: 9999px;
}
.pricing-scroll-container {
  scrollbar-width: none;
  -ms-overflow-style: none;
  -webkit-overflow-scrolling: touch;
}
.pricing-scroll-container::-webkit-scrollbar {
  display: none;
}
`;

export default function Pricing() {
  const sectionRef = useRef(null);
  const scrollContainerRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-80px' });

  // State Management
  const [activeCategory, setActiveCategory] = useState('both_side');
  const [singleSideFilter, setSingleSideFilter] = useState('all'); // 'all' | '3days' | '2days'
  const [viewMode, setViewMode] = useState('cards'); // 'cards' | 'table'
  const [selectedModalPackage, setSelectedModalPackage] = useState(null);
  const [mobileActiveIndex, setMobileActiveIndex] = useState(0);

  // Trigger celebration confetti when clicking WhatsApp booking
  const triggerConfetti = () => {
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#C5A059', '#E64A6E', '#D4AF37']
      });
    } catch (e) {
      // Ignore if unavailable
    }
  };

  // Get active packages filtered
  const getFilteredPackages = () => {
    const pkgs = PACKAGES_DATA[activeCategory] || [];
    if (activeCategory === 'single_side' && singleSideFilter !== 'all') {
      return pkgs.filter((p) => p.subCat === singleSideFilter);
    }
    return pkgs;
  };

  const activePackages = getFilteredPackages();

  // Open WhatsApp Link directly
  const openWhatsApp = (pkg) => {
    triggerConfetti();
    const text = encodeURIComponent(
      `Hello Frame Your Moments! I am interested in booking the *${pkg.name}* package (${pkg.duration || 'Event Coverage'}) priced at ₹${pkg.price}/-. Please share availability and booking procedure.`
    );
    window.open(`https://wa.me/918013346138?text=${text}`, '_blank');
  };

  /* ── Mobile Carousel Navigation ── */
  const scrollToCard = (index) => {
    if (!scrollContainerRef.current) return;
    const container = scrollContainerRef.current;
    const cards = container.children;
    if (cards[index]) {
      const card = cards[index];
      const scrollLeft = card.offsetLeft - (container.offsetWidth - card.offsetWidth) / 2;
      container.scrollTo({ left: scrollLeft, behavior: 'smooth' });
      setMobileActiveIndex(index);
    }
  };

  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    const container = scrollContainerRef.current;
    const scrollCenter = container.scrollLeft + container.offsetWidth / 2;
    const cards = container.children;
    let closest = 0;
    let minDist = Infinity;
    for (let i = 0; i < cards.length; i++) {
      const cardCenter = cards[i].offsetLeft + cards[i].offsetWidth / 2;
      const dist = Math.abs(scrollCenter - cardCenter);
      if (dist < minDist) {
        minDist = dist;
        closest = i;
      }
    }
    setMobileActiveIndex(closest);
  };

  return (
    <section
      ref={sectionRef}
      id="pricing"
      className="relative w-full py-24 sm:py-32 bg-[#FAF7F2] overflow-hidden border-t border-[#E8DFD1]/60"
    >
      <style dangerouslySetInnerHTML={{ __html: pricingStyles }} />

      {/* ── Subtle Luxury Background Lights ── */}
      <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-[#C5A059]/[0.06] rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute bottom-10 left-1/4 w-[600px] h-[600px] bg-[#E64A6E]/[0.04] rounded-full blur-[180px] pointer-events-none" />

      <div className="max-w-[1400px] mx-auto px-5 sm:px-10 lg:px-12 relative z-10 w-full">

        {/* ══════════ SECTION HEADER ══════════ */}
        <div className="flex flex-col items-center text-center mb-12 sm:mb-16">
          {/* Traditional Royal Fine-Art Line Divider */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="mb-5 flex items-center justify-center gap-3"
          >
            <div className="w-20 sm:w-32 h-[1px] bg-gradient-to-r from-transparent via-[#C5A059]/40 to-[#C5A059]/80" />
            <div className="flex items-center gap-2 text-[#C5A059]">
              <span className="w-1 h-1 rounded-full bg-[#C5A059]/60" />
              <div className="w-3.5 h-3.5 rotate-45 border border-[#C5A059] flex items-center justify-center">
                <div className="w-1.5 h-1.5 bg-[#C5A059]" />
              </div>
              <span className="w-1 h-1 rounded-full bg-[#C5A059]/60" />
            </div>
            <div className="w-20 sm:w-32 h-[1px] bg-gradient-to-l from-transparent via-[#C5A059]/40 to-[#C5A059]/80" />
          </motion.div>

          {/* Main Heading */}
          <motion.h2
            initial={{ opacity: 0, y: 25 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.15 }}
            className="font-serif-luxury text-4xl sm:text-6xl md:text-7xl italic text-[#1C1917] font-light mb-3"
          >
            Photography Packages
          </motion.h2>

          {/* Colored Dots */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex gap-2 mb-4"
          >
            <span className="w-2.5 h-2.5 rounded-full bg-[#E64A6E]" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#C5A059]" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#1C1917]/15" />
          </motion.div>

          {/* Subtext */}
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.35 }}
            className="font-sans text-[#57534E] max-w-2xl leading-relaxed text-sm sm:text-base"
          >
            Explore our curated collections for Both Side Weddings, Single Side Celebrations, Pre-Wedding Films, and Engagement Stories. Select a category below to discover your perfect plan.
          </motion.p>
        </div>

        {/* ══════════ CATEGORY NAVIGATION TABS ══════════ */}
        <div className="flex flex-col items-center mb-10 sm:mb-14">
          <div className="w-full max-w-4xl p-1.5 sm:p-2 bg-[#F3ECE0]/90 backdrop-blur-md rounded-2xl border border-[#E8DFD1] shadow-[0_4px_20px_rgba(0,0,0,0.03)] flex items-center justify-between gap-1 overflow-x-auto custom-table-scrollbar">
            {CATEGORIES.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    setActiveCategory(cat.id);
                    setMobileActiveIndex(0);
                  }}
                  className={`relative flex-1 py-3 px-3 sm:px-5 rounded-xl font-cinzel text-[10px] sm:text-[12px] tracking-[0.15em] uppercase font-semibold transition-all duration-300 flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
                    isActive ? 'text-[#1C1917]' : 'text-[#8A7968] hover:text-[#1C1917]'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeCategoryPill"
                      className="absolute inset-0 bg-white rounded-xl shadow-[0_4px_16px_rgba(197,160,89,0.18)] border border-[#C5A059]/30"
                      transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10 flex items-center gap-2">
                    {cat.id === 'both_side' && <Heart size={14} className={isActive ? 'text-[#E64A6E]' : 'text-[#8A7968]'} />}
                    {cat.id === 'single_side' && <Camera size={14} className={isActive ? 'text-[#C5A059]' : 'text-[#8A7968]'} />}
                    {cat.id === 'pre_wedding' && <Film size={14} className={isActive ? 'text-[#00A896]' : 'text-[#8A7968]'} />}
                    {cat.id === 'engagement' && <Sparkles size={14} className={isActive ? 'text-[#E64A6E]' : 'text-[#8A7968]'} />}
                    {cat.label}
                  </span>
                  <span className={`relative z-10 hidden sm:inline-block px-2 py-0.5 rounded-full text-[9px] font-sans ${
                    isActive ? 'bg-[#FAF7F2] text-[#C5A059] font-medium' : 'bg-black/5 text-[#8A7968]'
                  }`}>
                    {cat.badge}
                  </span>
                </button>
              );
            })}
          </div>

          {/* ── Sub-filters (Single Side Specific) & View Mode Switcher ── */}
          <div className="w-full max-w-4xl mt-5 flex flex-wrap items-center justify-between gap-4 px-2">
            
            {/* Single Side Sub-filter */}
            {activeCategory === 'single_side' ? (
              <div className="flex items-center gap-2 bg-[#F5EFE6] p-1 rounded-xl border border-[#E8DFD1]">
                <span className="font-cinzel text-[9px] tracking-[0.15em] uppercase text-[#8A7968] px-2.5 font-bold">
                  Duration:
                </span>
                {[
                  { id: 'all', label: 'All Packages' },
                  { id: '3days', label: '3-Day Groom/Bride' },
                  { id: '2days', label: '2-Day Packages' },
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setSingleSideFilter(f.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-sans font-medium transition-all cursor-pointer ${
                      singleSideFilter === f.id
                        ? 'bg-[#1C1917] text-white shadow'
                        : 'text-[#57534E] hover:bg-white/60'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            ) : <div />}

            {/* View Mode Switcher (Card Grid vs Comparison Matrix) */}
            <div className="flex items-center gap-1 bg-[#F5EFE6] p-1 rounded-xl border border-[#E8DFD1] ml-auto">
              <button
                onClick={() => setViewMode('cards')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-cinzel text-[10px] tracking-wider uppercase font-semibold transition-all cursor-pointer ${
                  viewMode === 'cards' ? 'bg-white text-[#1C1917] shadow-sm border border-[#E8DFD1]' : 'text-[#8A7968] hover:text-[#1C1917]'
                }`}
              >
                <GridIcon size={13} />
                <span>Showcase Cards</span>
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-cinzel text-[10px] tracking-wider uppercase font-semibold transition-all cursor-pointer ${
                  viewMode === 'table' ? 'bg-white text-[#1C1917] shadow-sm border border-[#E8DFD1]' : 'text-[#8A7968] hover:text-[#1C1917]'
                }`}
              >
                <TableIcon size={13} />
                <span>Compare Matrix</span>
              </button>
            </div>
          </div>
        </div>

        {/* ══════════ PACKAGES SHOWCASE CONTENT ══════════ */}
        <AnimatePresence mode="wait">
          {viewMode === 'cards' ? (
            <motion.div
              key={`cards-${activeCategory}-${singleSideFilter}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
            >
              {/* Mobile Carousel View */}
              <div className="relative lg:hidden">
                {activePackages.length > 1 && (
                  <>
                    <button
                      onClick={() => scrollToCard(Math.max(0, mobileActiveIndex - 1))}
                      className="absolute -left-2 top-1/2 -translate-y-1/2 z-30 w-9 h-9 rounded-full bg-white/90 backdrop-blur-md border border-[#E8DFD1] text-[#1C1917] flex items-center justify-center hover:bg-[#C5A059] hover:text-white transition-all shadow-lg cursor-pointer"
                      aria-label="Previous plan"
                    >
                      <ChevronLeft size={16} />
                    </button>
                    <button
                      onClick={() => scrollToCard(Math.min(activePackages.length - 1, mobileActiveIndex + 1))}
                      className="absolute -right-2 top-1/2 -translate-y-1/2 z-30 w-9 h-9 rounded-full bg-white/90 backdrop-blur-md border border-[#E8DFD1] text-[#1C1917] flex items-center justify-center hover:bg-[#C5A059] hover:text-white transition-all shadow-lg cursor-pointer"
                      aria-label="Next plan"
                    >
                      <ChevronRight size={16} />
                    </button>
                  </>
                )}

                <div
                  ref={scrollContainerRef}
                  onScroll={handleScroll}
                  className="pricing-scroll-container flex gap-4 overflow-x-auto snap-x snap-mandatory pt-4 pb-4 px-2"
                >
                  {activePackages.map((pkg, index) => (
                    <PackageCard
                      key={pkg.id}
                      pkg={pkg}
                      index={index}
                      isInView={isInView}
                      onOpenModal={() => setSelectedModalPackage(pkg)}
                      onBook={() => openWhatsApp(pkg)}
                      isMobile={true}
                    />
                  ))}
                </div>

                {/* Dots Indicator */}
                {activePackages.length > 1 && (
                  <div className="flex items-center justify-center gap-2 mt-4">
                    {activePackages.map((pkg, i) => (
                      <button
                        key={pkg.id}
                        onClick={() => scrollToCard(i)}
                        className={`transition-all duration-300 rounded-full cursor-pointer ${
                          mobileActiveIndex === i
                            ? 'w-7 h-2 bg-[#C5A059]'
                            : 'w-2 h-2 bg-[#E8DFD1] hover:bg-[#C5A059]/40'
                        }`}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Desktop Grid View (3 Columns or centered 2 / 1 columns) */}
              <div className={`hidden lg:grid gap-8 items-stretch ${
                activePackages.length === 1
                  ? 'grid-cols-1 max-w-md mx-auto'
                  : activePackages.length === 2
                  ? 'grid-cols-2 max-w-4xl mx-auto'
                  : 'grid-cols-3'
              }`}>
                {activePackages.map((pkg, index) => (
                  <PackageCard
                    key={pkg.id}
                    pkg={pkg}
                    index={index}
                    isInView={isInView}
                    onOpenModal={() => setSelectedModalPackage(pkg)}
                    onBook={() => openWhatsApp(pkg)}
                    isMobile={false}
                  />
                ))}
              </div>
            </motion.div>
          ) : (
            /* ══════════ COMPARISON MATRIX TABLE VIEW ══════════ */
            <motion.div
              key={`table-${activeCategory}-${singleSideFilter}`}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.4 }}
              className="bg-white rounded-3xl border border-[#E8DFD1] p-4 sm:p-8 shadow-[0_10px_40px_-10px_rgba(0,0,0,0.06)] overflow-hidden"
            >
              <div className="overflow-x-auto custom-table-scrollbar">
                <table className="w-full text-left border-collapse min-w-[750px]">
                  <thead>
                    <tr className="border-b border-[#E8DFD1]">
                      <th className="py-4 px-4 font-cinzel text-xs tracking-[0.2em] uppercase text-[#8A7968] w-1/4">
                        Package Specifications
                      </th>
                      {activePackages.map((pkg) => (
                        <th key={pkg.id} className="py-4 px-4 text-center">
                          {pkg.popular && (
                            <span className="inline-block px-2.5 py-0.5 rounded-full bg-[#E64A6E] text-white font-cinzel text-[8px] tracking-[0.2em] uppercase font-bold mb-1">
                              Popular Choice
                            </span>
                          )}
                          <div className="font-serif-luxury text-xl font-medium text-[#1C1917]">
                            {pkg.name}
                          </div>
                          <div className="mt-1 flex flex-col items-center">
                            {pkg.originalPrice && (
                              <span className="font-sans text-xs text-[#8A7968] line-through">
                                ₹{pkg.originalPrice}
                              </span>
                            )}
                            <span className="font-serif-luxury text-2xl text-[#C5A059] font-semibold">
                              ₹{pkg.price}/-
                            </span>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E8DFD1]/60 font-sans text-sm text-[#44403C]">
                    <tr>
                      <td className="py-3.5 px-4 font-semibold text-[#1C1917] flex items-center gap-2">
                        <Clock size={15} className="text-[#C5A059]" /> Coverage / Duration
                      </td>
                      {activePackages.map((pkg) => (
                        <td key={pkg.id} className="py-3.5 px-4 text-center font-medium">
                          {pkg.duration}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3.5 px-4 font-semibold text-[#1C1917] flex items-center gap-2">
                        <Camera size={15} className="text-[#C5A059]" /> Photographers
                      </td>
                      {activePackages.map((pkg) => (
                        <td key={pkg.id} className="py-3.5 px-4 text-center">
                          {pkg.photographers}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3.5 px-4 font-semibold text-[#1C1917] flex items-center gap-2">
                        <Video size={15} className="text-[#C5A059]" /> Cinematographers
                      </td>
                      {activePackages.map((pkg) => (
                        <td key={pkg.id} className="py-3.5 px-4 text-center">
                          {pkg.cinematographers}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3.5 px-4 font-semibold text-[#1C1917] flex items-center gap-2">
                        <Sparkles size={15} className="text-[#C5A059]" /> Aerial Drone Shoot
                      </td>
                      {activePackages.map((pkg) => (
                        <td key={pkg.id} className="py-3.5 px-4 text-center font-medium">
                          {pkg.drone && pkg.drone !== 'Not Included' ? (
                            <span className="text-[#00A896] font-semibold bg-[#00A896]/10 px-2.5 py-1 rounded-full text-xs inline-block">
                              {pkg.drone}
                            </span>
                          ) : (
                            <span className="text-[#A89F91]">✕ No Drone</span>
                          )}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3.5 px-4 font-semibold text-[#1C1917] flex items-center gap-2">
                        <BookOpen size={15} className="text-[#C5A059]" /> Albums & Books
                      </td>
                      {activePackages.map((pkg) => (
                        <td key={pkg.id} className="py-3.5 px-4 text-center text-xs">
                          {pkg.album || 'N/A'}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3.5 px-4 font-semibold text-[#1C1917] flex items-center gap-2">
                        <Film size={15} className="text-[#C5A059]" /> Video Deliverables
                      </td>
                      {activePackages.map((pkg) => (
                        <td key={pkg.id} className="py-3.5 px-4 text-center text-xs">
                          {pkg.video}
                        </td>
                      ))}
                    </tr>
                    {activeCategory === 'pre_wedding' && (
                      <tr>
                        <td className="py-3.5 px-4 font-semibold text-[#1C1917] flex items-center gap-2">
                          <Shirt size={15} className="text-[#C5A059]" /> Makeup & Designer Outfit
                        </td>
                        {activePackages.map((pkg) => (
                          <td key={pkg.id} className="py-3.5 px-4 text-center text-xs font-medium">
                            {pkg.makeupDress && pkg.makeupDress !== 'Not Included' ? (
                              <span className="text-[#E64A6E] font-semibold">{pkg.makeupDress}</span>
                            ) : (
                              <span className="text-[#A89F91]">✕ Not Included</span>
                            )}
                          </td>
                        ))}
                      </tr>
                    )}
                    <tr>
                      <td className="py-4 px-4 font-semibold text-[#1C1917]">Action</td>
                      {activePackages.map((pkg) => (
                        <td key={pkg.id} className="py-4 px-4 text-center">
                          <button
                            onClick={() => openWhatsApp(pkg)}
                            className="px-4 py-2 bg-[#1C1917] hover:bg-[#C5A059] text-white font-cinzel text-[10px] tracking-wider uppercase font-bold rounded-xl transition-all cursor-pointer"
                          >
                            Book Package
                          </button>
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ══════════ BOTTOM TRUST & ASSURANCE BAR ══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="mt-16 sm:mt-20"
        >
          <div className="flex items-center justify-center gap-4 mb-10">
            <div className="flex-1 max-w-[200px] h-[1px] bg-gradient-to-r from-transparent to-[#E8DFD1]" />
            <div className="w-1.5 h-1.5 rotate-45 border border-[#C5A059]/40" />
            <div className="flex-1 max-w-[200px] h-[1px] bg-gradient-to-l from-transparent to-[#E8DFD1]" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center max-w-4xl mx-auto">
            {[
              { icon: Shield, label: '100% Transparent Pricing', sublabel: 'No hidden taxes or extra costs' },
              { icon: Heart, label: 'Customizable Add-ons', sublabel: 'Tailored to your family rituals' },
              { icon: Award, label: '4.9 Google Rated', sublabel: '35+ Weddings Covered Last Year' },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 bg-white p-4 rounded-2xl border border-[#E8DFD1] shadow-xs">
                <div className="w-10 h-10 rounded-xl bg-[#FAF7F2] border border-[#E8DFD1] flex items-center justify-center text-[#C5A059] flex-shrink-0">
                  <item.icon size={18} />
                </div>
                <div className="text-left">
                  <span className="font-sans text-xs sm:text-sm font-semibold text-[#1C1917] block leading-tight">
                    {item.label}
                  </span>
                  <span className="font-cinzel text-[9px] tracking-wider uppercase text-[#8A7968]">
                    {item.sublabel}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <p className="text-center font-sans text-xs text-[#8A7968] mt-8 max-w-xl mx-auto leading-relaxed">
            Need a custom package or destination booking? Call or WhatsApp us directly at{' '}
            <a href="tel:+918013346138" className="font-bold text-[#1C1917] hover:underline">
              +91 8013346138
            </a>
          </p>
        </motion.div>

      </div>

      {/* ══════════ PACKAGE DETAIL MODAL ══════════ */}
      <AnimatePresence>
        {selectedModalPackage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6"
            onClick={() => setSelectedModalPackage(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 relative border border-[#E8DFD1] shadow-2xl"
            >
              <button
                onClick={() => setSelectedModalPackage(null)}
                className="absolute top-5 right-5 w-8 h-8 rounded-full bg-[#FAF7F2] border border-[#E8DFD1] flex items-center justify-center text-[#1C1917] hover:bg-[#1C1917] hover:text-white transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>

              <div className="pr-6">
                <span className="font-cinzel text-[10px] tracking-[0.2em] uppercase font-bold text-[#C5A059]">
                  {selectedModalPackage.duration}
                </span>
                <h3 className="font-serif-luxury text-3xl text-[#1C1917] font-medium mt-1">
                  {selectedModalPackage.name}
                </h3>
                <p className="font-sans text-xs text-[#8A7968] mt-1">
                  {selectedModalPackage.tagline}
                </p>

                <div className="my-5 p-4 rounded-2xl bg-[#FAF7F2] border border-[#E8DFD1] flex items-baseline justify-between">
                  <div>
                    <span className="text-[10px] font-cinzel text-[#8A7968] uppercase block">Investment</span>
                    {selectedModalPackage.originalPrice && (
                      <span className="text-xs text-[#8A7968] line-through mr-2">
                        ₹{selectedModalPackage.originalPrice}
                      </span>
                    )}
                    <span className="font-serif-luxury text-3xl text-[#1C1917] font-light">
                      ₹{selectedModalPackage.price}/-
                    </span>
                  </div>
                  {selectedModalPackage.badge && (
                    <span className="px-3 py-1 rounded-full bg-[#E64A6E] text-white font-cinzel text-[9px] tracking-wider uppercase font-bold">
                      {selectedModalPackage.badge}
                    </span>
                  )}
                </div>

                <h4 className="font-cinzel text-xs tracking-[0.2em] uppercase font-bold text-[#1C1917] mb-3">
                  Full Deliverable Specifications
                </h4>

                <ul className="space-y-3 font-sans text-xs text-[#44403C] mb-6">
                  <li className="flex items-start gap-2.5">
                    <Camera size={14} className="text-[#C5A059] shrink-0 mt-0.5" />
                    <span><strong>Photography:</strong> {selectedModalPackage.photographers}</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <Video size={14} className="text-[#C5A059] shrink-0 mt-0.5" />
                    <span><strong>Cinematography:</strong> {selectedModalPackage.cinematographers}</span>
                  </li>
                  {selectedModalPackage.drone && (
                    <li className="flex items-start gap-2.5">
                      <Sparkles size={14} className="text-[#C5A059] shrink-0 mt-0.5" />
                      <span><strong>Drone Shoot:</strong> {selectedModalPackage.drone}</span>
                    </li>
                  )}
                  <li className="flex items-start gap-2.5">
                    <Star size={14} className="text-[#C5A059] shrink-0 mt-0.5" />
                    <span><strong>Edited Photos:</strong> {selectedModalPackage.photos}</span>
                  </li>
                  {selectedModalPackage.album && selectedModalPackage.album !== 'Not Included' && (
                    <li className="flex items-start gap-2.5">
                      <BookOpen size={14} className="text-[#C5A059] shrink-0 mt-0.5" />
                      <span><strong>Albums:</strong> {selectedModalPackage.album}</span>
                    </li>
                  )}
                  <li className="flex items-start gap-2.5">
                    <Film size={14} className="text-[#C5A059] shrink-0 mt-0.5" />
                    <span><strong>Films & Video:</strong> {selectedModalPackage.video}</span>
                  </li>
                  {selectedModalPackage.extraDeliverables && selectedModalPackage.extraDeliverables.length > 0 && (
                    <li className="flex items-start gap-2.5">
                      <Gift size={14} className="text-[#C5A059] shrink-0 mt-0.5" />
                      <span><strong>Bonus Extras:</strong> {selectedModalPackage.extraDeliverables.join(', ')}</span>
                    </li>
                  )}
                </ul>

                <button
                  onClick={() => {
                    setSelectedModalPackage(null);
                    openWhatsApp(selectedModalPackage);
                  }}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#25D366] to-[#128C7E] text-white font-cinzel text-xs tracking-[0.2em] uppercase font-bold flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all cursor-pointer"
                >
                  <MessageCircle size={16} />
                  <span>Book via WhatsApp (+91 8013346138)</span>
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

/* ════════════════════════════════════════════════════════════════════
   PACKAGE CARD COMPONENT
   ════════════════════════════════════════════════════════════════════ */
function PackageCard({ pkg, index, isInView, onOpenModal, onBook, isMobile }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: 0.15 + index * 0.1 }}
      className={`relative group ${
        isMobile ? 'flex-shrink-0 w-[85vw] max-w-[340px] snap-center' : 'flex'
      }`}
    >
      <div
        className={`relative rounded-[28px] overflow-hidden transition-all duration-500 flex flex-col w-full bg-white border ${
          pkg.popular
            ? 'border-[#E64A6E]/40 shadow-[0_10px_40px_-10px_rgba(230,74,110,0.2)] hover:shadow-[0_16px_50px_-8px_rgba(230,74,110,0.3)] hover:scale-[1.01]'
            : 'border-[#E8DFD1] shadow-[0_6px_30px_-6px_rgba(0,0,0,0.05)] hover:shadow-[0_12px_40px_-6px_rgba(197,160,89,0.18)] hover:border-[#C5A059]/40'
        }`}
      >
        {/* Accent Bar */}
        <div
          className="h-1.5 w-full"
          style={{
            background: pkg.popular
              ? 'linear-gradient(90deg, #E64A6E, #D8335B)'
              : `linear-gradient(90deg, transparent, ${pkg.accent}, transparent)`,
          }}
        />

        {/* Badge Ribbon */}
        {pkg.badge && (
          <div className="absolute top-4 right-4 z-20">
            <span
              className={`px-3 py-1 rounded-full font-cinzel text-[9px] tracking-[0.18em] uppercase font-bold shadow-xs ${
                pkg.popular
                  ? 'bg-gradient-to-r from-[#E64A6E] to-[#D8335B] text-white'
                  : 'bg-[#F5EFE6] text-[#C5A059] border border-[#E8DFD1]'
              }`}
            >
              {pkg.badge}
            </span>
          </div>
        )}

        {/* Card Header */}
        <div className="p-6 sm:p-8 pb-4">
          <span className="font-cinzel text-[9px] tracking-[0.22em] uppercase font-bold text-[#8A7968]/70 block mb-1">
            {pkg.duration}
          </span>
          <h3 className="font-serif-luxury text-2xl sm:text-3xl text-[#1C1917] font-medium leading-snug">
            {pkg.name}
          </h3>
          <p className="font-sans text-xs text-[#8A7968] mt-1 line-clamp-1">
            {pkg.tagline}
          </p>

          {/* Pricing Display */}
          <div className="mt-5 pt-4 border-t border-[#E8DFD1]/60">
            {pkg.originalPrice && (
              <span className="font-sans text-xs text-[#8A7968] line-through block font-medium">
                ₹{pkg.originalPrice}/-
              </span>
            )}
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="font-cinzel text-xs text-[#8A7968]">₹</span>
              <span
                className="font-serif-luxury text-3xl sm:text-4xl font-light leading-none"
                style={{ color: pkg.accent }}
              >
                {pkg.price}
              </span>
              <span className="font-sans text-xs text-[#8A7968]">/-</span>
            </div>
          </div>
        </div>

        {/* Highlights List */}
        <div className="px-6 sm:px-8 pb-4 flex-1">
          <span className="font-cinzel text-[9px] tracking-[0.2em] uppercase text-[#8A7968] block mb-3 font-semibold">
            Deliverable Highlights
          </span>
          <ul className="space-y-2.5">
            {pkg.keyHighlights.map((h, i) => (
              <li key={i} className="flex items-start gap-2.5 text-xs font-sans text-[#57534E]">
                <Check size={14} className="text-[#C5A059] shrink-0 mt-0.5" strokeWidth={2.5} />
                <span>{h}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Card Footer Actions */}
        <div className="p-6 sm:p-8 pt-2 space-y-2">
          <button
            onClick={onBook}
            className={`w-full py-3.5 rounded-2xl font-cinzel text-[10px] sm:text-[11px] tracking-[0.2em] uppercase font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              pkg.popular
                ? 'bg-gradient-to-r from-[#E64A6E] via-[#E8557B] to-[#D8335B] text-white shadow-[0_6px_20px_rgba(230,74,110,0.3)] hover:scale-[1.02]'
                : 'bg-[#1C1917] text-white hover:bg-[#C5A059] hover:shadow-md'
            }`}
          >
            <span>Book Via WhatsApp</span>
            <ArrowRight size={13} />
          </button>

          <button
            onClick={onOpenModal}
            className="w-full py-2 text-center font-cinzel text-[9px] tracking-[0.18em] uppercase text-[#8A7968] hover:text-[#1C1917] transition-colors cursor-pointer"
          >
            View Full Specs Breakdown
          </button>
        </div>
      </div>
    </motion.div>
  );
}

